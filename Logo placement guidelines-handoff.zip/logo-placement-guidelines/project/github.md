repo: neuromali597-max/YAKUBA-AI-
branch: main

## Last sync

date: 2026-08-19T00:00:00Z
note: Repository associated by the user. GitHub browse tools were not available in this session, so no repository content has been read or imported yet. Designs so far are built from the written brief only.

### Updated in this project
- Landing page publique Yakuba AI (design, non issue du repo)

## Screen map

| Screen | Repo files |
| --- | --- |
| Yakuba AI — Landing.dc.html | (not yet mapped — repo not read) |
