repo: neuromali597-max/YAKUBA-AI-
branch: main

## Last sync
date: 2026-08-23T00:17:10Z

### Updated in this project
- Repo contains only README.md — no source imported; prototype built from the product brief.

## Screen map
| Screen | Repo files |
|---|---|
| Yakuba AI Mobile.dc.html (toutes sections) | — (aucune source dans le dépôt) |
